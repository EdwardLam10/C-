/***************************************************************
Title: README.txt
Author: Edward Lam
Date Created: 5/07/2017
Class: Spring 2017, CSCI 235-03, Mon & Wed 5:35pm-6:50pm
Professor: Michael Garod
Purpose: Assignment #3
***************************************************************/

Make File Instructions
make all - compiles all the files
make clean - delete all the .o files and executable
make run - runs the exectutable, if compiled already

Parts Complete/Incomplete
As far as I know, everything in the project was completed. 

Description of Known Bugs
Because I used .eof to retrieve words from the file, if the entered
.txt file has too much whitespace after the list of words, the entire
program may crash.
The program also cannot handle if the inputed .txt file is invalid 
or does not exist.

Algorithms and class structure
The project consists of 3 classes, all wrapping around another. The 
base of all of them is the trieNode class, which is wrapped by the 
trie class, which is wrapped by the dictionary class.
The suggest function in the dictionary uses a level order traversal to
find the shortest words in alphabetical order. 
The nodecount function in the trie class is recursive. Using a base case of
a node without any children, any other node will call the nodecount function
on all of its children, adding them up as it goes along.
Throughout the project I used the fact that if you add 1 to a letter it will
increment to letter by 1 to the next letter( ex. - 'a' + 1 = b). So many of 
my for loops started with 'a' and ended with '{' since '{' is the character
that follows 'z' on the ascii table.
I had originally tried to use an array to hold each of the nodes' children, however 
I encountered a strange problem where the last node of the array could not be set
to null. So I used maps instead.